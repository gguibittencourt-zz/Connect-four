# Connect-four with minmax alpha beta pruning #

This project has a implementation of minmax alpha beta pruning algorithm that solve the connect-four problem.

The implementation don't contais GUI. It's text mode.

The project was created as a graduation project.

Parts of the structura are from the website http://www3.ntu.edu.sg/home/ehchua/programming/java/javagame_tictactoe_ai.html

Authores:
Irenio Arag�o
Nildo Wilpert J�nior.